# AboutME tweak source

A Theos/Logos iOS tweak source project for a premium dark/gold About Me dialogue.

## Features
- Circular bundled avatar at `/Library/Application Support/AboutME/avatar.png`
- Display name: 𝐆ᴜᴍɴᴀᴍ🐺
- WhatsApp, TikTok, and YouTube buttons
- Close button
- Persistent “Don't show again” preference
- Automatic first display after the app becomes active
- Filter intended to restrict injection to Yalla Ludo

## Before building
1. Replace `REPLACE_WITH_YALLA_LUDO_BUNDLE_ID` in `filter.plist` with the app's exact `CFBundleIdentifier` from `YallaLudo.app/Info.plist`.
2. Replace `Resources/avatar.png` with your own square profile photo. Keep the filename `avatar.png`.
3. Confirm the package/injection method is compatible with your iOS version and device. A compiled tweak does not install or inject itself.

## Build with Theos
This source uses Theos and an iOS SDK. On a supported macOS/Linux build environment with Theos installed:
```sh
make clean package
```
The package output is typically under `packages/`.

## Asset packaging
The avatar must be copied to:
`/Library/Application Support/AboutME/avatar.png`

For a rootless jailbreak, the path and package layout may need to be adapted to the target's prefix (commonly `/var/jb`). The current project is a starter template for a rootful package.

## Important limitations
- This archive contains source/build files, not a precompiled `.dylib` or `.deb`.
- Building on Android Termux alone is not a dependable turnkey path: Theos plus a matching iOS SDK/toolchain is required. A Linux cloud runner or macOS/Linux build host is generally more practical.
- A non-jailbroken device usually needs a different IPA patching/re-signing workflow. Re-signing may affect entitlements, and injection is not guaranteed to work on every app/device.
- The current trigger attempts to present once per process after the app becomes active. Apps with unusual scene/window setups may need a target-specific hook.


## Build from a phone using GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP (including the hidden `.github` folder).
2. In `Makefile`, change the SDK target only if the selected build runner does not provide iOS SDK 16.5.
3. Replace the placeholder bundle identifier in `filter.plist` with the real Yalla Ludo bundle ID.
4. Open the repository's **Actions** tab, select **Build AboutME tweak**, and tap **Run workflow** (or push to `main`).
5. When the run finishes, open its summary and download the `AboutME-build` artifact. It contains the generated `.deb` package, if compilation succeeds.

Do not upload private certificates or signing keys to the repository. Keep the repository private if you do not want your source code public.
