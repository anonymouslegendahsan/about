#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <objc/runtime.h>

static NSString * const AMPreferenceKey = @"xyz.yallaludofasttyper.aboutme.dontshowagain";
static NSString * const AMWhatsAppURL = @"https://yallaludofasttyper.xyz/wp-channel.php";
static NSString * const AMTikTokURL = @"https://yallaludofasttyper.xyz/tiktok.php";
static NSString * const AMYouTubeURL = @"https://yallaludofasttyper.xyz/youTube.php";
static NSString * const AMDisplayName = @"𝐆ᴜᴍɴᴀᴍ🐺";

@interface AMAboutViewController : UIViewController
@end

@interface AMAboutViewController ()
@property(nonatomic, strong) UIView *panel;
@property(nonatomic, strong) UISwitch *dontShowSwitch;
@end

@implementation AMAboutViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.72];

    UIView *panel = [[UIView alloc] initWithFrame:CGRectZero];
    panel.translatesAutoresizingMaskIntoConstraints = NO;
    panel.backgroundColor = [UIColor colorWithRed:0.035 green:0.035 blue:0.035 alpha:1.0];
    panel.layer.cornerRadius = 24.0;
    panel.layer.borderWidth = 1.0;
    panel.layer.borderColor = [UIColor colorWithRed:0.72 green:0.56 blue:0.25 alpha:1.0].CGColor;
    panel.clipsToBounds = YES;
    [self.view addSubview:panel];
    self.panel = panel;

    [NSLayoutConstraint activateConstraints:@[
        [panel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [panel.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [panel.widthAnchor constraintEqualToAnchor:self.view.widthAnchor multiplier:0.84],
        [panel.widthAnchor constraintLessThanOrEqualToConstant:360],
    ]];

    UIButton *closeTop = [self buttonWithTitle:@"×" action:@selector(closeTapped)];
    closeTop.titleLabel.font = [UIFont systemFontOfSize:30 weight:UIFontWeightLight];
    [panel addSubview:closeTop];
    closeTop.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [closeTop.topAnchor constraintEqualToAnchor:panel.topAnchor constant:8],
        [closeTop.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12],
        [closeTop.widthAnchor constraintEqualToConstant:38],
        [closeTop.heightAnchor constraintEqualToConstant:38],
    ]];

    UIImageView *avatar = [[UIImageView alloc] initWithImage:[self bundledAvatar]];
    avatar.translatesAutoresizingMaskIntoConstraints = NO;
    avatar.contentMode = UIViewContentModeScaleAspectFill;
    avatar.layer.cornerRadius = 48;
    avatar.layer.borderWidth = 2.5;
    avatar.layer.borderColor = [UIColor colorWithRed:0.82 green:0.66 blue:0.34 alpha:1].CGColor;
    avatar.clipsToBounds = YES;
    [panel addSubview:avatar];

    UILabel *name = [[UILabel alloc] initWithFrame:CGRectZero];
    name.translatesAutoresizingMaskIntoConstraints = NO;
    name.text = AMDisplayName;
    name.textAlignment = NSTextAlignmentCenter;
    name.textColor = [UIColor colorWithRed:0.96 green:0.82 blue:0.52 alpha:1];
    name.font = [UIFont systemFontOfSize:21 weight:UIFontWeightSemibold];
    name.adjustsFontSizeToFitWidth = YES;
    name.minimumScaleFactor = 0.72;
    [panel addSubview:name];

    UILabel *subtitle = [[UILabel alloc] initWithFrame:CGRectZero];
    subtitle.translatesAutoresizingMaskIntoConstraints = NO;
    subtitle.attributedText = [[NSAttributedString alloc] initWithString:@"ABOUT ME"
        attributes:@{NSKernAttributeName:@2.0,
                     NSForegroundColorAttributeName:[UIColor colorWithWhite:0.68 alpha:1],
                     NSFontAttributeName:[UIFont systemFontOfSize:11 weight:UIFontWeightMedium]}];
    subtitle.textAlignment = NSTextAlignmentCenter;
    [panel addSubview:subtitle];

    UIStackView *socialStack = [[UIStackView alloc] initWithFrame:CGRectZero];
    socialStack.translatesAutoresizingMaskIntoConstraints = NO;
    socialStack.axis = UILayoutConstraintAxisVertical;
    socialStack.spacing = 10;
    socialStack.distribution = UIStackViewDistributionFillEqually;
    [panel addSubview:socialStack];
    [socialStack addArrangedSubview:[self socialButton:@"WhatsApp" symbol:@"message.fill" url:AMWhatsAppURL]];
    [socialStack addArrangedSubview:[self socialButton:@"TikTok" symbol:@"music.note" url:AMTikTokURL]];
    [socialStack addArrangedSubview:[self socialButton:@"YouTube" symbol:@"play.rectangle.fill" url:AMYouTubeURL]];

    UIView *preferenceRow = [[UIView alloc] initWithFrame:CGRectZero];
    preferenceRow.translatesAutoresizingMaskIntoConstraints = NO;
    [panel addSubview:preferenceRow];

    UILabel *dontShow = [[UILabel alloc] initWithFrame:CGRectZero];
    dontShow.translatesAutoresizingMaskIntoConstraints = NO;
    dontShow.text = @"Don't show again";
    dontShow.textColor = [UIColor colorWithWhite:0.83 alpha:1];
    dontShow.font = [UIFont systemFontOfSize:13];
    [preferenceRow addSubview:dontShow];

    UISwitch *toggle = [[UISwitch alloc] initWithFrame:CGRectZero];
    toggle.translatesAutoresizingMaskIntoConstraints = NO;
    toggle.onTintColor = [UIColor colorWithRed:0.72 green:0.56 blue:0.25 alpha:1];
    toggle.on = [[NSUserDefaults standardUserDefaults] boolForKey:AMPreferenceKey];
    [preferenceRow addSubview:toggle];
    self.dontShowSwitch = toggle;

    UIButton *closeButton = [self buttonWithTitle:@"CLOSE" action:@selector(closeTapped)];
    closeButton.backgroundColor = [UIColor colorWithRed:0.78 green:0.62 blue:0.32 alpha:1];
    [closeButton setTitleColor:[UIColor colorWithRed:0.06 green:0.05 blue:0.03 alpha:1] forState:UIControlStateNormal];
    closeButton.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightBold];
    closeButton.layer.cornerRadius = 12;
    [panel addSubview:closeButton];
    closeButton.translatesAutoresizingMaskIntoConstraints = NO;

    [NSLayoutConstraint activateConstraints:@[
        [avatar.topAnchor constraintEqualToAnchor:panel.topAnchor constant:30],
        [avatar.centerXAnchor constraintEqualToAnchor:panel.centerXAnchor],
        [avatar.widthAnchor constraintEqualToConstant:96],
        [avatar.heightAnchor constraintEqualToConstant:96],

        [name.topAnchor constraintEqualToAnchor:avatar.bottomAnchor constant:14],
        [name.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:18],
        [name.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-18],

        [subtitle.topAnchor constraintEqualToAnchor:name.bottomAnchor constant:5],
        [subtitle.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:12],
        [subtitle.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-12],

        [socialStack.topAnchor constraintEqualToAnchor:subtitle.bottomAnchor constant:22],
        [socialStack.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:20],
        [socialStack.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-20],

        [preferenceRow.topAnchor constraintEqualToAnchor:socialStack.bottomAnchor constant:18],
        [preferenceRow.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:22],
        [preferenceRow.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-18],
        [preferenceRow.heightAnchor constraintEqualToConstant:32],

        [dontShow.leadingAnchor constraintEqualToAnchor:preferenceRow.leadingAnchor],
        [dontShow.centerYAnchor constraintEqualToAnchor:preferenceRow.centerYAnchor],
        [toggle.trailingAnchor constraintEqualToAnchor:preferenceRow.trailingAnchor],
        [toggle.centerYAnchor constraintEqualToAnchor:preferenceRow.centerYAnchor],

        [closeButton.topAnchor constraintEqualToAnchor:preferenceRow.bottomAnchor constant:14],
        [closeButton.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:20],
        [closeButton.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-20],
        [closeButton.heightAnchor constraintEqualToConstant:44],
        [closeButton.bottomAnchor constraintEqualToAnchor:panel.bottomAnchor constant:-20],
    ]];
}

- (UIButton *)buttonWithTitle:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor colorWithRed:0.92 green:0.76 blue:0.45 alpha:1] forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (UIButton *)socialButton:(NSString *)title symbol:(NSString *)symbol url:(NSString *)urlString {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    button.backgroundColor = [UIColor colorWithRed:0.085 green:0.08 blue:0.07 alpha:1];
    button.layer.cornerRadius = 12;
    button.layer.borderWidth = 1;
    button.layer.borderColor = [UIColor colorWithWhite:0.20 alpha:1].CGColor;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    button.titleEdgeInsets = UIEdgeInsetsMake(0, 14, 0, 0);
    [button setTitle:[@"   " stringByAppendingString:title] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    UIImage *image = [UIImage systemImageNamed:symbol];
    [button setImage:image forState:UIControlStateNormal];
    button.tintColor = [UIColor colorWithRed:0.82 green:0.66 blue:0.34 alpha:1];
    button.imageEdgeInsets = UIEdgeInsetsMake(0, 14, 0, 0);
    objc_setAssociatedObject(button, @selector(openSocial:), urlString, OBJC_ASSOCIATION_COPY_NONATOMIC);
    [button addTarget:self action:@selector(openSocial:) forControlEvents:UIControlEventTouchUpInside];
    [button.heightAnchor constraintEqualToConstant:48].active = YES;
    return button;
}

- (void)openSocial:(UIButton *)sender {
    NSString *urlString = objc_getAssociatedObject(sender, @selector(openSocial:));
    NSURL *url = [NSURL URLWithString:urlString];
    if (url) [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:nil];
}

- (UIImage *)bundledAvatar {
    NSString *path = @"/Library/Application Support/AboutME/avatar.png";
    UIImage *image = [UIImage imageWithContentsOfFile:path];
    if (image) return image;
    // Safe visual fallback if the package's avatar asset has not been installed.
    UIGraphicsBeginImageContextWithOptions(CGSizeMake(160, 160), YES, 1);
    [[UIColor colorWithRed:0.10 green:0.09 blue:0.07 alpha:1] setFill];
    UIRectFill(CGRectMake(0, 0, 160, 160));
    NSDictionary *attrs = @{NSFontAttributeName:[UIFont systemFontOfSize:62 weight:UIFontWeightSemibold],
                            NSForegroundColorAttributeName:[UIColor colorWithRed:0.82 green:0.66 blue:0.34 alpha:1]};
    [@"G" drawAtPoint:CGPointMake(52, 43) withAttributes:attrs];
    UIImage *fallback = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return fallback;
}

- (void)closeTapped {
    [[NSUserDefaults standardUserDefaults] setBool:self.dontShowSwitch.isOn forKey:AMPreferenceKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self dismissViewControllerAnimated:YES completion:nil];
}
@end

static void AMShowIfNeeded(void) {
    if ([[NSUserDefaults standardUserDefaults] boolForKey:AMPreferenceKey]) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIApplication *app = [UIApplication sharedApplication];
        UIWindow *window = nil;
        if (@available(iOS 13.0, *)) {
            for (UIScene *scene in app.connectedScenes) {
                if (scene.activationState != UISceneActivationStateForegroundActive) continue;
                if (![scene isKindOfClass:[UIWindowScene class]]) continue;
                for (UIWindow *candidate in ((UIWindowScene *)scene).windows) {
                    if (candidate.isKeyWindow) { window = candidate; break; }
                }
                if (window) break;
            }
        }
        if (!window) window = app.keyWindow;
        UIViewController *root = window.rootViewController;
        while (root.presentedViewController) root = root.presentedViewController;
        if (!root || root.view.window == nil) return;
        AMAboutViewController *vc = [AMAboutViewController new];
        vc.modalPresentationStyle = UIModalPresentationOverFullScreen;
        vc.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
        [root presentViewController:vc animated:YES completion:nil];
    });
}

%ctor {
    @autoreleasepool {
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                                                          object:nil
                                                           queue:[NSOperationQueue mainQueue]
                                                      usingBlock:^(__unused NSNotification *note) {
            static BOOL didAttemptThisProcess = NO;
            if (didAttemptThisProcess) return;
            didAttemptThisProcess = YES;
            AMShowIfNeeded();
        }];
    }
}
